<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <script src="jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/sport.css">
    <link rel="stylesheet" href="css/header.css">
    <title>Document</title>
    <script>
      $(document).ready(function(){
            $('#icon').click(function(){
                $('ul').toggleClass('show')
            })
        })
    </script>
</head>
<body>
    <div class="header">
        <div class="droite">
            <p class="foncer">Université de Yaoundé 1</p>
            <p>sapienta-collativa-cognito</p>
            <p class="foncer">Cameroun</p>
        </div>
        <div class="uy1">
            <img src="images/images.png" alt="" width="150" height="170px">
        </div>
        <div class="gauche">
            <p class="foncer">University of Yaoundé 1</p>
            <p>sapienta-collativa-cognito</p>
            <p class="foncer"> Cameroon</p>
        </div>
    </div><br><br>
    <nav>
      <ul>
        <li><a href="acceuil.html"><i class="fa fa-layer-group"></i> Home</a></li>
        <li><a href="index.html">Universite de yaounde</a></li>
        <li><a href="contact.php">Contact us</a></li>
        <li><a a class="active" href="formulaire.php">Inscription</a></li>
        <li><a href="admin.php">Log in</a></li>
      </ul>  
      <label id="icon">
        <i class="fas fa-bars"></i>
      </label>
    </nav>
   <br><br>
      <h1>Sport informations</h1>
      <div class="container">
        <form action="">
            <label for="Practiced sport">Practiced sport</label><br>
            <select class="sel" id="" name="">
                <option value="">football</option>
                <option value="">handball</option>
                <option value="">volleyball</option>
              </select><br>
              <label for="Art Practiced">Art Practiced"</label><br>
              <select class="sel" id="" name="">
                  <option value="">chant</option>
                  <option value="">dessins</option>
                  <option value="">others</option>
                </select> <br>
                <label >Do you have a disability?*</label><br>
              <select class="sel" id="" name="">
                  <option value="">Yes</option>
                  <option value="">No</option>
                </select> <br><br>
                <input type="text" placeholder="Medical certificate number" name="" id="" required>
                <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
                <a href="filiation.php"> <button  class="registerbtn">Precedent</button></a>
              <button type="submit" class="registerbtn">Enregistrer</button>
              </div>
        </form>

      <div class="footer">
        <h2>University of Yaoundé I</h2>
        <h3>Copyright ©2022 All rights reserved | CUTI UY1</h3>
  
       </div>
</body>
</html>