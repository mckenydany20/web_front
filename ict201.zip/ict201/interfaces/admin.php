<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <script src="jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/header.css">
    <title>Document</title>
    <script>
        $(document).ready(function(){
            $('#icon').click(function(){
                $('ul').toggleClass('show')
            })
        })

var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 300);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
    </script>
</head>
<body onload="myFunction()" style="margin:0;">

  <div id="loader"></div>
  
  <div style="display:none;" id="myDiv" class="animate-bottom">
    <div class="header">
        <div class="droite">
            <p class="foncer">Université de Yaoundé 1</p>
            <p>sapienta-collativa-cognito</p>
            <p class="foncer">Cameroun</p>
        </div>
        <div class="uy1">
            <img src="images/images.png" alt="" width="150" height="170px">
        </div>
        <div class="gauche">
            <p class="foncer">University of Yaoundé 1</p>
            <p>sapienta-collativa-cognito</p>
            <p class="foncer"> Cameroon</p>
        </div>
    </div><br><br>
   
    <nav>
      <ul>
        <li><a href="acceuil.html"><i class="fa fa-layer-group"></i> Home</a></li>
        <li><a href="index.html">Universite de yaounde</a></li>
        <li><a href="contact.php">Contact us</a></li>
        <li><a href="formulaire.php">Inscription</a></li>
        <li><a a class="active" href="admin.php">Log in</a></li>
      </ul>  
      <label id="icon">
        <i class="fas fa-bars"></i>
      </label>
    </nav>
    <br><br>
      <h1>LOG IN...</h1>
      <div class="container">
        <form action="">
                <input type="text" placeholder="Enter Email" name="email" id="email" required>
                <input type="password" placeholder="Enter Password" name="psw" id="psw" required>
                <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
                <button type="submit" class="registerbtn">Register</button>
              </div>
            
              <div class="container signin">
                <p>Already have an account? <a href="#">Sign in</a>.</p>
        </form>

    </div>

      <div class="footer">
        <h2>University of Yaoundé I</h2>
        <h3>Copyright ©2022 All rights reserved | CUTI UY1</h3>
  
      </div>    
 </div>
</body>
</html>