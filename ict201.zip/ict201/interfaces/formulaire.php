<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <script src="jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/formulaire.css">
    <link rel="stylesheet" href="css/header.css">
    <title>Document</title>
    <script>
       $(document).ready(function(){
            $('#icon').click(function(){
                $('ul').toggleClass('show')
            })
        })
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 300);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
    </script>
</head>

<body onload="myFunction()" style="margin:0;">

  <div id="loader"></div>
  
  <div style="display:none;" id="myDiv" class="animate-bottom">
    <div class="header">
        <div class="droite">
            <p class="foncer">Université de Yaoundé 1</p>
            <p>sapienta-collativa-cognito</p>
            <p class="foncer">Cameroun</p>
        </div>
        <div class="uy1">
            <img src="images/images.png" alt="" width="150" height="170px">
        </div>
        <div class="gauche">
            <p class="foncer">University of Yaoundé 1</p>
            <p>sapienta-collativa-cognito</p>
            <p class="foncer"> Cameroon</p>
        </div>
    </div><br><br>
    <nav>
      <ul>
        <li><a href="acceuil.html"><i class="fa fa-layer-group"></i> Home</a></li>
        <li><a href="index.html">Universite de yaounde</a></li>
        <li><a href="contact.php">Contact us</a></li>
        <li><a a class="active" href="formulaire.php">Inscription</a></li>
        <li><a href="admin.php">Log in</a></li>
      </ul>  
      <label id="icon">
        <i class="fas fa-bars"></i>
      </label>
    </nav>
  <br><br>
      <h1>INSCRIPTION...</h1>
      <div class="container">

        <input type="text" placeholder="name" name="" id="" required>
        <input type="text" placeholder="surname" name="" id="" required>

        <input type="date" placeholder="Birthday" name="" id="" required><br><br>
        <label >Is this the date marked on your birth certificate?
        </label><br>
              <select class="sel" id="" name="">
                  <option value="">Yes</option>
                  <option value="">No</option>
                </select> <br><br>
        <input type="text" placeholder="Place of birth" name="" id="" required><br>
        <label >Gender</label><br>
        <select class="sel" id="" name="">
            <option value="">Masculin</option>
            <option value="">Feminin</option>
          </select> <br><br>
       
        <input type="text" placeholder="adress" name="" id="" required><br>
        <input type="number" placeholder="phone number" name="" id="" required><br><br>
        <label >your first language</label><br>
                      <select class="sel" id="" name="">
                          <option value="">French</option>
                          <option value="">English</option>
                        </select> <br><br>

       <input type="text" placeholder="Gender" name="" id="" required>
       <input type="email" placeholder="adress email" name="" id="" required>
       <input type="text" placeholder="nationality" name="" id="" required><br>
       <label >Marital status*
      </label><br>
            <select class="sel" id="" name="">
                <option value="">Marrié</option>
                <option value="">Celibataire</option>
                <option value="">Divorcé</option>
              </select> <br><br>
      <label > region of origin
              </label><br>
                    <select class="sel" id="" name="">
                        <option value="">Extreme-nord</option>
                        <option value="">Nord</option>
                        <option value="">Adamaoua</option>
                        <option value="">Nord-ouest</option>
                        <option value="">Centre</option>
                        <option value="">Sud-ouest</option>
                        <option value="">Sud</option>
                        <option value="">Est</option>
                        <option value="">Ouest</option>
                        <option value="">Littoral</option>
                      </select> <br><br>
     
                            
       <input type="text" placeholder="name of father" name="" id="" required>
       <input type="text" placeholder="profession of father" name="" id="" required>
       <input type="text" placeholder="name of mother" name="" id="" required>
       <input type="text" placeholder="profession of father" name="" id="" required><br>
       <label >serie names
      </label><br>
              <select class="sel" id="" name="">
                  <option value="">A</option>
                  <option value="">B</option>
                  <option value="">C</option>
                  <option value="">D</option>
                  <option value="">E</option>
                  <option value="">F1</option>
                  <option value="">F2</option>
                  <option value="">F3</option>
                  <option value="">F4</option>
                  <option value="">F5</option>
                  <option value="">F6</option>
                  <option value="">F7</option>
                  <option value="">F8</option>
                  <option value="">TI</option>
                  <option value="">OTHERS</option>
                </select> <br><br>
                <label >Mention*
                </label><br>
                                      <select class="sel" id="" name="">
                                          <option value="">Passable</option>
                                          <option value="">Assez-Bien</option>
                                          <option value="">Bien</option>
                                          <option value="">Tres Bien</option>
                                          <option value="">Excellent</option>
                                        </select> <br><br>
        <label >desired level*
                </label><br>
                      <select class="sel" id="" name="">
                          <option value="">L1</option>
                          <option value="">L2</option>
                          <option value="">L3</option>
                        </select> <br><br>
                        <label >first choice
        </label><br>
                              <select class="sel" id="" name="">
                                  <option value="">INFORMATIQUE</option>
                                  <option value="">ICT4D</option>
                                  <option value="">MATHEMATIQUES</option>
                                  <option value="">PHYSIQUE</option>
                                  <option value="">CHIMIE </option>
                                  <option value="">GEOSCIENCES</option>
                                  <option value="">BIOSCIENCES</option>
                                  <option value="">BIOCHIMIE</option>
                                  <option value=""> CHIMIE ORGANIQUE</option>
                                </select> <br><br>
        <label >second choice
                                </label><br>
                                <select class="sel" id="" name="">
                                  <option value="">INFORMATIQUE</option>
                                  <option value="">ICT4D</option>
                                  <option value="">MATHEMATIQUES</option>
                                  <option value="">PHYSIQUE</option>
                                  <option value="">CHIMIE </option>
                                  <option value="">GEOSCIENCES</option>
                                  <option value="">BIOSCIENCES</option>
                                  <option value="">BIOCHIMIE</option>
                                  <option value=""> CHIMIE ORGANIQUE</option>
                                </select> <br><br>
        <label >third choice
                      </label><br>
                      <select class="sel" id="" name="">
                        <option value="">INFORMATIQUE</option>
                        <option value="">ICT4D</option>
                        <option value="">MATHEMATIQUES</option>
                        <option value="">PHYSIQUE</option>
                        <option value="">CHIMIE </option>
                        <option value="">GEOSCIENCES</option>
                        <option value="">BIOSCIENCES</option>
                        <option value="">BIOCHIMIE</option>
                        <option value=""> CHIMIE ORGANIQUE</option>
                      </select> <br><br>
             <input type="number" placeholder="average obtained" name="" id="" required><br><br>
             <a href="filiation.php"> <button type="submit" class="registerbtn">Suivant</button></a>
      </div>
      <div class="footer">
        <h2>University of Yaoundé I</h2>
        <h3>Copyright ©2022 All rights reserved | CUTI UY1</h3>
       </div>
</div>
</body>
</html>