<?php
session_start() ;


if(!isset($_SESSION['info1'] )) {
    echo "bonjour" ;
    header("location: formulaire.php") ;
}