<?php



foreach($_POST  as $key => $value ) {
  $info1["$key"] = htmlspecialchars(trim($value));

} 

// $_SESSION['info1'] = $info1 ;

// print_r($_SESSION['info1']) ;

// header("location: ok.php") ;



?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">
    <title>Document</title>
</head>
<body>
    <header>
      <div class="container container_univerty_name">
        <div class="container_univerty_name1">
          <h1>Université de Yaoundé 1</h1>
          <p id="cognito">sapienta-collativa-cognito</p>
          <p>cameroun</p>
        </div>
        
        <img src="./Blason_univ_Yaoundé_1.png" alt="" />
        
        <div>
          <h1>Université de Yaoundé 1</h1>
          <p id="cognito">sapienta-collativa-cognito</p>
          <p>cameroun</p>
        </div>
      </div>
      <nav>
        <div class="container">
          <ul style="list-style: none ;">
            <li><a href="#">Home</a></li>
            <li><a href="#">Universite yaounde 1</a></li>
            <li><a href="#">Contact us</a></li>
            <li><a href="#">Inscription</a></li>
            <li><a href="#">Help</a></li>
            <li><a href="#">Login</a></li>
          </ul>
        </div>
      </nav>
    </header>


    <section class="info-procedure-formulaire">
        <div class="container info-procedure-formulaires">
            <aside>
            <div class="aside-header">
              Liste des pièces à fournir pour le dépôt physique du dossier
            </div>
  
            <div class="aside-body">
              <ul class="my-list">
                <li>
                  Reçu de paiement des frais de préinscription qui s'élèvent à 10
                  000 FCFA payables à la Société Générale Cameroun (SGC) et à
                  Express Union (EU).
                </li>
                <li>02 exemplaires de votre fiche de préinscription.</li>
                <li>
                  Photocopie Certifiée Conforme du Relevé de Notes du
                  Baccalauréat. Photocopie Certifiée
                </li>
                <li>
                  Photocopie Certifiée Conforme du Probatoire/GCE-O Level ou de
                  l’Attestation de Réussite.
                </li>
                <li>
                  Photocopie Certifiée Conforme du diplôme de Licence ou son
                  équivalent pour l’accès à la Faculté des Sciences de
                  l’Education.
                </li>
                <li>Photocopie certifiée conforme de l’Acte de naissance.</li>
                <li>04 photos couleurs 4x4.</li>
              </ul>
            </div>
          </aside>
           <form action="" method="POST">
            <h1>Préinscription en Faculté des Sciences de <br> l'Education (FSE)</h1>
            <span>Tous les champs marqués d'un <span class="red-etoile">*</span> sont obligatoires.</span>

            <div class="fiels">
                <label for="name">Nom <span >*</span></label>
                <div class="fiels-input" >
                    <input type="text" id="name" name="Nom" value="<?= $info1['Nom'] ?>" required>
                </div>
            </div>

            <div class="fiels">
                <label for="prenom">Prenom(s) <span >*</span></label>
                <div class="fiels-input" >
                    <input type="text" id="prenom" name="prenom" value="<?= $info1['prenom']  ?>" required>
                </div>
            </div>

            <div class="fiels">
                <label for="date_naissance"> Date de naissance <span >*</span></label>
                <div class="fiels-input" >
                    <input type="date" id="date_naissance" name="dateNaissance" value="<?= $info1['dateNaissance'] ?>" required>
                </div>
            </div>

            <div class="fiels">
                <label for="lieu_naissance"> Lieu de naissance <span >*</span></label>
                <div class="fiels-input" >
                    <input type="text" id="lieu_naissance" name="lieuNaissance" value="<?= $info1['lieuNaissance'] ?>" required>
                </div>
            </div>

            <div class="fiels">
                <label for="Numéro_de_CNI"> Numéro de CNI <span >*</span></label>
                <div class="fiels-input" >
                    <input type="text" id="Numéro_de_CNI" name="numeroDeCNI" value="<?= $info1['numeroDeCNI'] ?>" required>
                </div>
            </div>

            

            <div class="fiels">
                <label for="Numéro_de_CNI"> Sexe <span >*</span></label>
                <div class="fiels-input" >
                   <select name="Sexe" id=""  required>
                    <option value="FEMININ">FEMININ</option>
                    <option value="MASCULIN">MASCULIN</option>
                   </select>
                </div>
            </div>

            <div class="fiels">
                <label for="Adresse">Adresse <span >*</span></label>
                <div class="fiels-input" >
                    <input type="text" id="Adresse" name="adresse" value="<?= $info1['adresse'] ?> " required>
                </div>
                <span class="oriantation">Votre quartier de résidence. Exemple: Obili</span>
            </div>

            
            <div class="fiels">
                <label for="Téléphone"> Téléphone <span >*</span></label>
                <div class="fiels-input" >
                    <input type="text" id="Téléphone" name="telephone" value="<?= $info1['telephone'] ?> " required>
                </div>
                <span class="oriantation" >Ne pas mettre les espaces. Exemple: 655565758</span>
            </div>

           


            <div class="fiels">
                <label for="Statut_marital "> Statut marital <span >*</span></label>
                <div class="fiels-input" >
                   <select name="statutMarital" id="Statut_marital">
                    <option value="CELIBATAIRE">CELIBATAIRE</option>
                    <option value="MARIE(E)">MARIE(E)</option>
                    <option value="DIVORCE(E)">DIVORCE(E)</option>
                   </select>
                </div>
            </div>


            <div class="fiels">
                <label for=" Première-langue "> Première langue <span >*</span></label>
                <div class="fiels-input" >
                   <select name="premieLangue" id="Première-langue" required>
                    <option value="FRANCAIS" >FRANCAIS</option>
                    <option value="ANGLAIS" >ANGLAIS</option>
                   </select>
                </div>
            </div>


          <div class="box-btn">
            <button class="btn btn-1" >Precedent</button>
            <button type="submit"  class="btn btn-2" >Suivant</button>
          </div>



           </form>
          
        </div>
      </section>
    
</body>
</html>

<?php

echo '<pre>' ;

print_r($info1) ;

echo '</pre>' ;
 
 echo ' '.$info1[ 'prenom' ] ; 

?>